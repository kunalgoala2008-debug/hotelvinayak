export interface RoomPlan {
  name: string;
  price: number;
  description: string;
}

export interface Room {
  id: string;
  name: string;
  image: string;
  tagline: string;
  plans: RoomPlan[];
  amenities: string[];
}

export interface Attraction {
  name: string;
  image: string;
  distance: string;
  description: string;
}

export interface Amenity {
  name: string;
  iconName: string;
  description: string;
}

export interface GalleryItem {
  id: string;
  image: string;
  caption: string;
  category: "rooms" | "exterior" | "spiritual" | "dining";
}

export interface Testimonial {
  name: string;
  location: string;
  rating: number;
  comment: string;
  date: string;
}

export interface BookingFormInput {
  name: string;
  phone: string;
  email: string;
  checkIn: string;
  checkOut: string;
  guests: number;
  message: string;
  roomType: string;
  planType: string;
}
