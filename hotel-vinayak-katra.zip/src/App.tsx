import { useState } from "react";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import About from "./components/About";
import Rooms from "./components/Rooms";
import WhyChooseUs from "./components/WhyChooseUs";
import Amenities from "./components/Amenities";
import Gallery from "./components/Gallery";
import Attractions from "./components/Attractions";
import Testimonials from "./components/Testimonials";
import Map from "./components/Map";
import Contact from "./components/Contact";
import WhatsApp from "./components/WhatsApp";
import { Sparkles, Heart } from "lucide-react";

export default function App() {
  const [selectedRoom, setSelectedRoom] = useState<string>("DOUBLE BED ROOM");
  const [selectedPlan, setSelectedPlan] = useState<string>("EP Plan");

  // Smooth scroll handler to reservation form
  const handleScrollToContact = () => {
    const contactSection = document.getElementById("contact");
    if (contactSection) {
      contactSection.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  // When guest selects room card or pricing plan trigger scroll & state select
  const handleBookRoom = (roomName: string, planName: string) => {
    setSelectedRoom(roomName);
    setSelectedPlan(planName);
    handleScrollToContact();
  };

  return (
    <div className="relative min-h-screen bg-luxury-black text-white selection:bg-gold/30 selection:text-white overflow-x-hidden antialiased">
      {/* Absolute top grid mesh layer for extra texture */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#111111_1px,transparent_1px),linear-gradient(to_bottom,#111111_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] pointer-events-none z-0" />

      {/* Floating Header */}
      <Navbar onBookClick={handleScrollToContact} />

      {/* Hero Banner Slide Intro */}
      <Hero onBookClick={handleScrollToContact} />

      {/* Main Container Content */}
      <main className="relative z-10">
        {/* Warm About Sanctuary */}
        <About />

        {/* Modular Room Packages */}
        <Rooms onBookRoom={handleBookRoom} />

        {/* Strategic Reasons */}
        <WhyChooseUs />

        {/* Premium Amenities Grid */}
        <Amenities />

        {/* Visual Showcase Gallery */}
        <Gallery />

        {/* Pilgrim Attractions & Map */}
        <Attractions />
        <Map />

        {/* Interactive Reviews */}
        <Testimonials />

        {/* Contact form & FAQ and Reservation */}
        <Contact
          selectedRoom={selectedRoom}
          selectedPlan={selectedPlan}
          setSelectedRoom={setSelectedRoom}
          setSelectedPlan={setSelectedPlan}
        />
      </main>

      {/* WhatsApp Chat Floating Desk */}
      <WhatsApp />

      {/* Clean Premium Footer */}
      <footer className="relative bg-black py-16 border-t border-gold/15 text-center overflow-hidden">
        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[500px] h-[150px] bg-gold/5 rounded-full blur-[80px] pointer-events-none" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 space-y-8">
          <div className="flex flex-col items-center space-y-3">
            <span className="font-display text-xl sm:text-2xl font-bold text-white tracking-[0.2em] uppercase">
              HOTEL VINAYAK
            </span>
            <span className="font-sans text-[10px] text-gold tracking-[0.3em] font-medium uppercase">
              A Unit of Maa Chaya Group
            </span>
          </div>

          <div className="w-16 h-[1px] bg-gold/25 mx-auto"></div>

          <p className="font-sans text-xs text-gray-400 font-light max-w-2xl mx-auto leading-relaxed">
            Located directly on Ban Ganga Road, Katra, offering budget luxury suites, 100% pure vegetarian catering, and dedicated support slips to families visiting the holy shrine of Mata Vaishno Devi.
          </p>

          <div className="flex flex-wrap justify-center gap-6 sm:gap-10 pt-4 text-xs font-semibold uppercase tracking-wider text-gray-400 font-sans">
            <a href="#home" className="hover:text-gold transition-colors duration-200">Home</a>
            <a href="#about" className="hover:text-gold transition-colors duration-200">About Us</a>
            <a href="#rooms" className="hover:text-gold transition-colors duration-200">Rooms & Rates</a>
            <a href="#facilities" className="hover:text-gold transition-colors duration-200">Facilities</a>
            <a href="#gallery" className="hover:text-gold transition-colors duration-200">Gallery</a>
            <a href="#contact" className="hover:text-gold transition-colors duration-200">Bookings</a>
          </div>

          <div className="pt-8 border-t border-white/5 flex flex-col sm:flex-row justify-between items-center text-[11px] text-gray-500 font-sans font-light gap-4">
            <p>
              &copy; {new Date().getFullYear()} Hotel Vinayak Katra. All rights reserved.
            </p>
            <div className="flex items-center space-x-1">
              <span>Managed with devotion by</span>
              <span className="font-medium text-gold">Maa Chaya Group</span>
              <Heart className="w-3.5 h-3.5 fill-gold text-gold" />
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
