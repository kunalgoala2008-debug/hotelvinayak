import { MapPin, Compass, Sparkles } from "lucide-react";

interface Attraction {
  name: string;
  image: string;
  distance: string;
  badge: string;
  description: string;
}

const ATTRACTIONS: Attraction[] = [
  {
    name: "Mata Vaishno Devi Bhawan",
    image: "https://images.unsplash.com/photo-1626014303757-6fc647d5770d?q=80&w=800",
    distance: "13 Km (Trek from Ban Ganga)",
    badge: "The Holy Shrine",
    description: "The ultimate sacred destination, nestled in the gorgeous Trikuta Hills at an altitude of 5200 feet.",
  },
  {
    name: "Ban Ganga",
    image: "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?q=80&w=800",
    distance: "Walking Distance from Hotel",
    badge: "Starting Point of Trek",
    description: "The sacred stream where Mata Vaishno Devi wiped her holy hair. Pilgrims take a purifying holy dip here before climbing.",
  },
  {
    name: "Katra Market",
    image: "https://images.unsplash.com/photo-1563013544-824ae1d704d3?q=80&w=800",
    distance: "2 Mins Walk",
    badge: "Shopping & Souvenirs",
    description: "Vibrant shopping stalls offering dry fruits (walnuts, almonds), woolen garments, leather crafts, and sacred bhawans.",
  },
  {
    name: "Yatra Registration Counter",
    image: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?q=80&w=800",
    distance: "5 Mins Walk",
    badge: "Essential Slip Counter",
    description: "Conveniently close to obtain your RFID Yatra Access Cards or physical slips before initiating the pilgrimage.",
  },
  {
    name: "Amarnath Yatra Transit Route",
    image: "https://images.unsplash.com/photo-1519681393784-d120267933ba?q=80&w=800",
    distance: "Strategic Transit Station",
    badge: "National Highway Link",
    description: "An ideal and safe base camp transit lodging for pilgrims proceeding towards Baltal, Pahalgam, and Jammu routing.",
  },
];

export default function Attractions() {
  return (
    <section id="attractions" className="py-24 sm:py-32 bg-luxury-black relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="text-center space-y-3 mb-20">
          <span className="font-sans text-xs sm:text-sm font-bold text-gold uppercase tracking-[0.3em] block">
            Local Proximity
          </span>
          <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold tracking-wide text-white">
            Nearby <span className="serif-italics font-serif text-gold font-normal">Attractions</span>
          </h2>
          <div className="w-24 h-[1px] bg-gold mx-auto mt-4"></div>
          <p className="font-sans text-xs sm:text-sm text-gray-300 max-w-xl mx-auto font-light tracking-wide mt-3">
            Hotel Vinayak enjoys a highly strategic, central location, positioning you minutes from critical pilgrimage landmarks.
          </p>
        </div>

        {/* Attractions Horizontal Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {ATTRACTIONS.map((attraction, index) => (
            <div
              key={index}
              className="group glass border border-gold/20 hover:border-gold hover:bg-white/5 overflow-hidden shadow-2xl transition-all duration-500 flex flex-col h-full"
            >
              {/* Image box with overlay */}
              <div className="relative aspect-[16/11] overflow-hidden border-b border-gold/15">
                <img
                  src={attraction.image}
                  alt={attraction.name}
                  loading="lazy"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />
                
                {/* Visual category tag */}
                <div className="absolute top-4 left-4 bg-luxury-black/95 backdrop-blur-md px-3.5 py-1.5 border border-gold/25 flex items-center space-x-1">
                  <Sparkles className="w-2.5 h-2.5 text-gold" />
                  <span className="font-sans text-[9px] font-bold text-gold tracking-widest uppercase">
                    {attraction.badge}
                  </span>
                </div>
              </div>

              {/* Detail body */}
              <div className="p-6 sm:p-8 flex-grow flex flex-col justify-between space-y-4">
                <div className="space-y-2">
                  <h3 className="font-display text-sm sm:text-base font-bold tracking-wide text-white uppercase group-hover:text-gold transition-colors duration-200">
                    {attraction.name}
                  </h3>
                  <p className="font-sans text-xs text-gray-400 leading-relaxed font-light">
                    {attraction.description}
                  </p>
                </div>

                {/* Distance display bar */}
                <div className="flex items-center space-x-2 pt-4 border-t border-gold/15 text-gold">
                  <MapPin className="w-4 h-4 flex-shrink-0" />
                  <span className="font-sans text-[11px] font-bold uppercase tracking-wider">
                    {attraction.distance}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Travel Advisory Callout */}
        <div className="mt-16 glass text-white p-8 border border-gold/30 relative overflow-hidden backdrop-blur-md">
          <div className="absolute top-0 right-0 w-32 h-32 bg-gold/10 rounded-full blur-2xl pointer-events-none" />
          <div className="relative z-10 flex flex-col md:flex-row justify-between items-center gap-6">
            <div className="space-y-2">
              <span className="font-sans text-[9px] font-bold text-gold tracking-widest uppercase block">
                Maa Chaya Pilgrim Desk
              </span>
              <h3 className="font-display text-base font-bold uppercase tracking-widest text-white">
                Need Help with RFID Slips or Battery Cars?
              </h3>
              <p className="font-sans text-xs text-gray-300 font-light max-w-2xl">
                Avoid queues. Our in-house travel assistance desk helps guests obtain priority slips, reserve helicopter tickets (Katra to Sanjichhat), and arrange reliable pony/palki services.
              </p>
            </div>
            <a
              href="https://wa.me/919650625613"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-gold hover:bg-white text-luxury-black font-sans text-xs font-bold uppercase tracking-widest px-6 py-4 transition-colors duration-300 whitespace-nowrap"
            >
              Consult Pilgrim Desk
            </a>
          </div>
        </div>

      </div>
    </section>
  );
}
