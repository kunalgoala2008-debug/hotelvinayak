import { MapPin, Check, Award, Compass, Heart, ShieldCheck } from "lucide-react";

export default function About() {
  const highlights = [
    {
      title: "Vaishno Devi Trip Expert",
      desc: "Comprehensive guidance, registration support, and Yatra planning.",
      icon: Compass,
    },
    {
      title: "Amarnath Yatra Expert",
      desc: "Strategic transit route accommodation and crucial registration tips.",
      icon: ShieldCheck,
    },
    {
      title: "Comfortable Family Stay",
      desc: "Spacious multi-bed rooms designed for families and large groups.",
      icon: Heart,
    },
    {
      title: "Budget Luxury Experience",
      desc: "Exceptional luxury, premium amenities, and affordable pricing plans.",
      icon: Award,
    },
  ];

  return (
    <section id="about" className="py-24 sm:py-32 bg-luxury-black relative overflow-hidden">
      {/* Subtle decorative background watermarks */}
      <div className="absolute top-10 left-1/2 -translate-x-1/2 font-display text-[12vw] text-gold/3 pointer-events-none uppercase tracking-widest whitespace-nowrap font-bold select-none">
        OM NAMO NARAYANI
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-center">
          
          {/* Text Left Column */}
          <div className="lg:col-span-7 space-y-8">
            <div className="space-y-3">
              <span className="font-sans text-xs sm:text-sm font-bold text-gold uppercase tracking-[0.25em] block">
                Welcome to Maa Chaya Group
              </span>
              <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold tracking-wide text-white leading-tight">
                Your Spiritual <br />
                <span className="serif-italics font-serif text-gold font-normal">Stay Partner</span> in Katra
              </h2>
              <div className="w-20 h-[1px] bg-gold mt-4"></div>
            </div>

            <p className="font-sans text-sm sm:text-base text-gray-300 leading-relaxed font-light">
              Situated on the auspicious route of Ban Ganga Road, **Hotel Vinayak Katra** serves as a premier sanctuary for pilgrims embarking on their sacred journeys to the holy shrine of Mata Vaishno Devi. Built on the core values of traditional hospitality, personal care, and modern convenience, we ensure your holy pilgrimage is comfortable, peaceful, and spiritually enriching.
            </p>

            <p className="font-sans text-sm sm:text-base text-gray-300 leading-relaxed font-light">
              Whether you are here for the holy **Vaishno Devi Darshan** or heading on the **Amarnath Yatra**, our experienced staff handles all details of your stay. We are steps away from critical transit points, combining supreme luxury with accessibility.
            </p>

            {/* Grid of Highlights */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-4">
              {highlights.map((item, index) => {
                const IconComponent = item.icon;
                return (
                  <div key={index} className="flex space-x-4 p-5 glass shadow-lg hover:bg-white/10 hover:translate-y-[-2px] transition-all duration-300">
                    <div className="p-2 bg-white/5 text-gold self-start border border-gold/10">
                      <IconComponent className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-display text-xs font-bold text-white tracking-wider uppercase mb-1">
                        {item.title}
                      </h3>
                      <p className="font-sans text-xs text-gray-400 leading-relaxed font-light">
                        {item.desc}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Proximity Fast Facts */}
            <div className="pt-4 border-t border-gold/15 space-y-4">
              <h4 className="font-display text-xs font-bold text-white tracking-widest uppercase">
                Location & Proximity Benefits
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="flex items-center space-x-3">
                  <Check className="w-4 h-4 text-gold flex-shrink-0" />
                  <span className="font-sans text-xs text-gray-300 font-medium">Walking Distance from Ban Ganga</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Check className="w-4 h-4 text-gold flex-shrink-0" />
                  <span className="font-sans text-xs text-gray-300 font-medium">Close to Katra Bus Stand</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Check className="w-4 h-4 text-gold flex-shrink-0" />
                  <span className="font-sans text-xs text-gray-300 font-medium">Personalized 24×7 Hospitality</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Check className="w-4 h-4 text-gold flex-shrink-0" />
                  <span className="font-sans text-xs text-gray-300 font-medium">Free Local Travel Advisory</span>
                </div>
              </div>
            </div>

            {/* Address Board */}
            <div className="p-6 bg-luxury-gray/90 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-6 border border-gold/30 shadow-xl backdrop-blur-md">
              <div className="flex items-start space-x-4">
                <MapPin className="w-6 h-6 text-gold flex-shrink-0 mt-1" />
                <div>
                  <h5 className="font-display text-xs font-bold tracking-widest text-gold uppercase mb-1">
                    Official Address
                  </h5>
                  <p className="font-sans text-xs text-gray-300 leading-relaxed font-medium">
                    Ban Ganga Road, Near Bus Stand,<br />
                    Katra, Jammu & Kashmir 182301
                  </p>
                </div>
              </div>
              <a
                href="#contact"
                className="inline-block self-start sm:self-center bg-gold hover:bg-white text-luxury-black font-sans text-xs font-bold uppercase tracking-wider px-5 py-3 transition-colors duration-300 whitespace-nowrap"
              >
                Get Directions
              </a>
            </div>

          </div>

          {/* Luxury Images Right Column with Offset Collage */}
          <div className="lg:col-span-5 relative mt-12 lg:mt-0">
            {/* Background frame */}
            <div className="absolute -inset-4 border border-gold/15 translate-x-4 translate-y-4 pointer-events-none hidden sm:block"></div>

            {/* Large Front Image */}
            <div className="relative shadow-2xl overflow-hidden border border-gold/20 aspect-[4/5] sm:aspect-square md:aspect-[4/5]">
              <img
                src="https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?q=80&w=1200"
                alt="Luxury Hotel Guest Lounge"
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
              <div className="absolute bottom-4 left-4 right-4 bg-luxury-black/85 backdrop-blur-md p-4 border border-gold/20">
                <p className="font-sans text-[10px] text-gold tracking-widest font-semibold uppercase">
                  Maa Chaya Standard
                </p>
                <p className="font-serif text-sm text-white italic mt-1">
                  "Excellence in Pilgrimage Hospitality"
                </p>
              </div>
            </div>

            {/* Smaller Offset Image */}
            <div className="absolute -bottom-10 -left-10 w-2/3 shadow-2xl border border-gold/20 hidden sm:block aspect-[4/3] overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1566073771259-6a8506099945?q=80&w=800"
                alt="Premium Welcome Entrance"
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
            </div>
            
          </div>

        </div>
      </div>
    </section>
  );
}
