import { useState, useEffect } from "react";
import { ChevronDown, ArrowRight, Sparkles } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface HeroProps {
  onBookClick: () => void;
}

const HERO_IMAGES = [
  {
    url: "https://images.unsplash.com/photo-1566073771259-6a8506099945?q=80&w=1920",
    alt: "Hotel Vinayak Katra Exterior",
  },
  {
    url: "https://images.unsplash.com/photo-1582719508461-905c673771fd?q=80&w=1920",
    alt: "Luxury Double Room",
  },
  {
    url: "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?q=80&w=1920",
    alt: "Misty Mountains of Jammu Kashmir",
  },
  {
    url: "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?q=80&w=1920",
    alt: "Premium Room Interior",
  },
];

export default function Hero({ onBookClick }: HeroProps) {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % HERO_IMAGES.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section id="home" className="relative w-full h-screen overflow-hidden bg-black">
      {/* Background Image Slider with Cross-fade & Ken Burns Zoom */}
      <div className="absolute inset-0 z-0">
        <AnimatePresence mode="popLayout">
          <motion.div
            key={currentIndex}
            initial={{ opacity: 0, scale: 1.08 }}
            animate={{ opacity: 1, scale: 1.02 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1.5, ease: "easeInOut" }}
            className="absolute inset-0 w-full h-full"
          >
            <img
              src={HERO_IMAGES[currentIndex].url}
              alt={HERO_IMAGES[currentIndex].alt}
              className="w-full h-full object-cover filter brightness-[0.4]"
              referrerPolicy="no-referrer"
            />
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Decorative Golden Ambient Light */}
      <div className="absolute bottom-0 left-0 w-full h-1/3 bg-gradient-to-t from-black via-black/40 to-transparent z-1" />

      {/* Hero Content */}
      <div className="relative z-10 w-full h-full flex flex-col justify-center items-center px-4 sm:px-6 lg:px-8 text-center select-none">
        {/* Subtle Welcome Badge */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.8 }}
          className="flex items-center space-x-2 border border-gold/40 px-4 py-1.5 mb-6 backdrop-blur-md bg-black/30"
        >
          <Sparkles className="w-3.5 h-3.5 text-gold animate-pulse" />
          <span className="font-sans text-[10px] sm:text-xs font-bold text-gold uppercase tracking-[0.3em]">
            A Unit of Maa Chaya Group
          </span>
        </motion.div>

        {/* Brand Name Title */}
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 1 }}
          className="font-display text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold tracking-[0.12em] text-white uppercase drop-shadow-xl mb-3"
        >
          HOTEL VINAYAK
          <span className="block text-2xl sm:text-3xl md:text-4xl text-gold tracking-[0.2em] font-medium mt-2">
            KATRA
          </span>
        </motion.h1>

        {/* Line Divider */}
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: "80px" }}
          transition={{ delay: 0.8, duration: 0.8 }}
          className="h-[1px] bg-gold my-4"
        />

        {/* Subheadings */}
        <motion.p
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1, duration: 0.8 }}
          className="font-serif text-lg sm:text-xl md:text-2xl text-gold-light italic tracking-wide max-w-3xl mb-2 drop-shadow"
        >
          Luxury Stay Near Mata Vaishno Devi
        </motion.p>

        <motion.p
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.2, duration: 0.8 }}
          className="font-sans text-xs sm:text-sm text-gray-200 tracking-wider max-w-2xl font-light mb-10 drop-shadow"
        >
          Trusted by Pilgrims for Vaishno Devi & Amarnath Yatra
        </motion.p>

        {/* Interactive Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.4, duration: 0.8 }}
          className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-6 w-full sm:w-auto px-6 sm:px-0"
        >
          <button
            id="hero-book-now"
            onClick={onBookClick}
            className="group relative bg-gold hover:bg-gold-dark text-luxury-black font-sans text-xs sm:text-sm font-bold uppercase tracking-widest px-8 py-4 transition-all duration-300 hover:shadow-[0_0_25px_rgba(212,175,55,0.4)] flex items-center justify-center space-x-2"
          >
            <span>Book Your Stay</span>
            <ArrowRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" />
          </button>
          <a
            id="hero-explore-rooms"
            href="#rooms"
            className="group border border-white hover:border-gold hover:text-gold text-white font-sans text-xs sm:text-sm font-semibold uppercase tracking-widest px-8 py-4 backdrop-blur-sm bg-white/5 transition-all duration-300 flex items-center justify-center space-x-2"
          >
            <span>Explore Rooms</span>
          </a>
        </motion.div>
      </div>

      {/* Progress indicators */}
      <div className="absolute bottom-10 right-10 z-10 hidden sm:flex items-center space-x-3">
        {HERO_IMAGES.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentIndex(index)}
            className={`h-1.5 transition-all duration-500 rounded-none ${
              index === currentIndex ? "w-8 bg-gold" : "w-2 bg-white/40 hover:bg-white"
            }`}
            aria-label={`Slide ${index + 1}`}
          />
        ))}
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 z-10 flex flex-col items-center">
        <a href="#about" className="text-white hover:text-gold transition-colors duration-300 flex flex-col items-center">
          <span className="font-sans text-[9px] uppercase tracking-[0.25em] mb-2 font-medium opacity-70">
            Discover More
          </span>
          <motion.div
            animate={{ y: [0, 8, 0] }}
            transition={{ repeat: Infinity, duration: 1.8, ease: "easeInOut" }}
          >
            <ChevronDown className="w-5 h-5 text-gold" />
          </motion.div>
        </a>
      </div>
    </section>
  );
}
