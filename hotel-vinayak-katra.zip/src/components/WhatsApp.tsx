import { MessageSquare, Sparkles } from "lucide-react";
import { motion } from "motion/react";

export default function WhatsApp() {
  return (
    <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end group select-none">
      
      {/* Elegantly styled hover label tooltip */}
      <div className="glass text-white border border-gold/30 backdrop-blur-md px-4 py-2 mb-3 mr-1 opacity-0 translate-y-2 pointer-events-none group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-300 shadow-2xl flex items-center space-x-2">
        <Sparkles className="w-3 h-3 text-gold animate-pulse" />
        <span className="font-sans text-[10px] font-bold uppercase tracking-widest text-gold whitespace-nowrap">
          Pilgrim Support (24x7)
        </span>
      </div>

      {/* Floating Action Button */}
      <a
        id="whatsapp-floating-btn"
        href="https://wa.me/919650625613"
        target="_blank"
        rel="noopener noreferrer"
        className="relative flex items-center justify-center w-14 h-14 bg-emerald-600 hover:bg-emerald-700 text-white rounded-full shadow-2xl shadow-emerald-950/40 hover:scale-110 transition-transform duration-300"
        title="Chat with Maa Chaya Group on WhatsApp"
      >
        {/* Animated ambient pulse glow rings in gold/green */}
        <span className="absolute inset-0 rounded-full bg-emerald-600/30 animate-ping" />
        <span className="absolute inset-0 rounded-full border border-gold/30 scale-125 animate-pulse" />

        {/* Custom icon */}
        <MessageSquare className="w-6 h-6 fill-white" />
      </a>
    </div>
  );
}
