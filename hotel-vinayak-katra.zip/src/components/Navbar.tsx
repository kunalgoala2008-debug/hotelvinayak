import { useState, useEffect } from "react";
import { Menu, X, Phone, CalendarDays } from "lucide-react";
import { AnimatePresence, motion } from "motion/react";

interface NavbarProps {
  onBookClick: () => void;
}

export default function Navbar({ onBookClick }: NavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { name: "Home", href: "#home" },
    { name: "About Us", href: "#about" },
    { name: "Rooms", href: "#rooms" },
    { name: "Facilities", href: "#facilities" },
    { name: "Gallery", href: "#gallery" },
    { name: "Nearby Attractions", href: "#attractions" },
    { name: "Contact", href: "#contact" },
  ];

  return (
    <>
      <nav
        id="main-navbar"
        className={`fixed top-0 left-0 w-full z-50 transition-all duration-500 ${
          isScrolled
            ? "glass-nav py-3 shadow-lg shadow-black/20"
            : "bg-gradient-to-b from-black/80 to-transparent py-5"
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center">
            {/* Brand Logo */}
            <a href="#home" className="flex flex-col group">
              <span className="font-display text-lg sm:text-xl md:text-2xl font-bold text-white tracking-widest group-hover:text-gold transition-colors duration-300">
                HOTEL VINAYAK
              </span>
              <span className="font-sans text-[9px] sm:text-[10px] text-gold tracking-[0.25em] font-medium uppercase transition-colors duration-300">
                A Unit of Maa Chaya Group
              </span>
            </a>

            {/* Desktop Navigation */}
            <div className="hidden lg:flex items-center space-x-8">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  className="font-sans text-xs font-semibold uppercase tracking-wider text-white hover:text-gold transition-colors duration-300 relative py-1 group"
                >
                  {link.name}
                  <span className="absolute bottom-0 left-0 w-0 h-[1px] bg-gold transition-all duration-300 group-hover:w-full"></span>
                </a>
              ))}
            </div>

            {/* Contact / CTA buttons */}
            <div className="hidden md:flex items-center space-x-4">
              <a
                href="tel:+919650625613"
                className="flex items-center space-x-2 text-white hover:text-gold transition-colors duration-300 font-sans text-xs font-semibold uppercase tracking-wider"
              >
                <Phone className="w-4 h-4 text-gold" />
                <span>+91 9650625613</span>
              </a>
              <button
                id="nav-book-now"
                onClick={onBookClick}
                className="flex items-center space-x-2 bg-gold hover:bg-gold-dark text-luxury-black font-sans text-xs font-bold uppercase tracking-wider px-5 py-2.5 rounded-none transition-all duration-300 hover:shadow-[0_0_15px_rgba(212,175,55,0.4)]"
              >
                <CalendarDays className="w-4 h-4" />
                <span>Book Now</span>
              </button>
            </div>

            {/* Mobile Menu Trigger */}
            <div className="lg:hidden flex items-center space-x-4">
              <a
                href="tel:+919650625613"
                className="md:hidden text-white hover:text-gold p-1"
                title="Call Us"
              >
                <Phone className="w-5 h-5 text-gold" />
              </a>
              <button
                id="mobile-menu-toggle"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="text-white hover:text-gold focus:outline-none p-1.5"
                aria-label="Toggle menu"
              >
                {isMobileMenuOpen ? (
                  <X className="w-6 h-6" />
                ) : (
                  <Menu className="w-6 h-6" />
                )}
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Mobile Drawer Navigation */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMobileMenuOpen(false)}
              className="fixed inset-0 bg-black/85 z-45 backdrop-blur-sm"
            />

            {/* Content Drawer */}
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              className="fixed right-0 top-0 h-full w-[280px] sm:w-[350px] bg-luxury-black/95 backdrop-blur-md z-50 p-8 flex flex-col justify-between border-l border-gold/20"
            >
              <div>
                <div className="flex justify-between items-center mb-10">
                  <div className="flex flex-col">
                    <span className="font-display text-base font-bold text-white tracking-widest">
                      HOTEL VINAYAK
                    </span>
                    <span className="font-sans text-[8px] text-gold tracking-[0.25em] font-medium uppercase">
                      A Unit of Maa Chaya Group
                    </span>
                  </div>
                  <button
                    id="mobile-menu-close"
                    onClick={() => setIsMobileMenuOpen(false)}
                    className="text-white hover:text-gold p-1"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="flex flex-col space-y-6">
                  {navLinks.map((link) => (
                    <a
                      key={link.name}
                      href={link.href}
                      onClick={() => setIsMobileMenuOpen(false)}
                      className="font-sans text-xs font-semibold uppercase tracking-widest text-white hover:text-gold transition-colors duration-200 py-1 border-b border-white/5"
                    >
                      {link.name}
                    </a>
                  ))}
                </div>
              </div>

              <div className="space-y-6">
                <a
                  href="tel:+919650625613"
                  className="flex items-center space-x-3 text-white hover:text-gold transition-colors duration-200"
                >
                  <Phone className="w-5 h-5 text-gold" />
                  <span className="font-sans text-xs font-medium tracking-wide">
                    +91 9650625613
                  </span>
                </a>
                <button
                  id="mobile-drawer-book-now"
                  onClick={() => {
                    setIsMobileMenuOpen(false);
                    onBookClick();
                  }}
                  className="w-full flex items-center justify-center space-x-2 bg-gold hover:bg-gold-dark text-luxury-black font-sans text-xs font-bold uppercase tracking-widest py-3.5 rounded-none transition-all duration-300"
                >
                  <CalendarDays className="w-4 h-4" />
                  <span>Book Your Stay</span>
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
