import { MapPin, Navigation, Map as MapIcon } from "lucide-react";

export default function Map() {
  return (
    <section id="map-location" className="py-20 bg-luxury-black relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Localized Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Location Text Details (5 cols) */}
          <div className="lg:col-span-5 space-y-6">
            <span className="font-sans text-xs font-bold text-gold uppercase tracking-[0.3em] block">
              Directions & Map
            </span>
            <h2 className="font-display text-3xl font-bold tracking-wide text-white uppercase">
              Our Prime <br />
              <span className="serif-italics font-serif text-gold font-normal lowercase">location</span>
            </h2>
            <div className="w-16 h-[1px] bg-gold"></div>
 
            <p className="font-sans text-xs sm:text-sm text-gray-300 leading-relaxed font-light">
              We are located directly on **Ban Ganga Road**, the official sacred pathway to the holy shrine of Mata Vaishno Devi. From our lobby, you are just a brief, flat walk to the Ban Ganga check-point.
            </p>
 
            {/* Proximity facts */}
            <div className="space-y-4 pt-4 border-t border-gold/15">
              <div className="flex items-start space-x-3">
                <MapPin className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-display text-[10px] font-bold text-white tracking-widest uppercase">
                    Hotel Vinayak Katra
                  </h4>
                  <p className="font-sans text-xs text-gray-400 font-light">
                    Ban Ganga Road, Near Bus Stand, Katra, Jammu & Kashmir 182301
                  </p>
                </div>
              </div>
 
              <div className="flex items-start space-x-3">
                <Navigation className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-display text-[10px] font-bold text-white tracking-widest uppercase">
                    Katra Bus Stand
                  </h4>
                  <p className="font-sans text-xs text-gray-400 font-light">
                    Only a 2-3 minute flat walk, making checking-in and tour transfers completely effortless.
                  </p>
                </div>
              </div>
            </div>
 
            {/* Directions button */}
            <div className="pt-4">
              <a
                href="https://maps.google.com/?q=Hotel+Vinayak+Katra+Ban+Ganga+Road+Katra"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center space-x-2 bg-gold hover:bg-white text-luxury-black font-sans text-xs font-bold uppercase tracking-widest px-6 py-3.5 transition-colors duration-300 border border-gold/15 cursor-pointer"
              >
                <MapIcon className="w-4 h-4" />
                <span>Open in Google Maps</span>
              </a>
            </div>
          </div>
 
          {/* Map Frame Embed (7 cols) */}
          <div className="lg:col-span-7 glass p-4 shadow-2xl relative aspect-[16/10] sm:aspect-[16/9] w-full">
            <iframe
              title="Hotel Vinayak Katra Google Map Location"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3340.5404554313264!2d74.9298457!3d33.0026219!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x391e7bc8c0000001%3A0xc319208eb6758eb0!2sHotel%20Vinayak%20Katra!5e0!3m2!1sen!2sin!4v1710000000000!5m2!1sen!2sin"
              className="w-full h-full border-0 filter grayscale hover:grayscale-0 transition-all duration-700"
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            ></iframe>
          </div>
 
        </div>
 
      </div>
    </section>
  );
}
