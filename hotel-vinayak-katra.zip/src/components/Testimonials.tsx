import { useState, useEffect } from "react";
import { Star, Quote, Sparkles, ChevronLeft, ChevronRight } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface Testimonial {
  name: string;
  location: string;
  rating: number;
  comment: string;
  date: string;
}

const TESTIMONIALS_DATA: Testimonial[] = [
  {
    name: "Ramesh Kumar Sharma",
    location: "New Delhi",
    rating: 5,
    comment: "The absolute best place to stay in Katra for Vaishno Devi. Extremely clean rooms, very helpful staff, and situated right on Ban Ganga Road! Maa Chaya Group's hospitality is outstanding.",
    date: "June 2026",
  },
  {
    name: "Dr. Ananya Iyer",
    location: "Chennai",
    rating: 5,
    comment: "We travelled with elderly parents. The elevator was a lifesaver, and the staff arranged a battery car slip for my father near the registration counter. Clean toilets and hot water 24/7. Highly recommended!",
    date: "May 2026",
  },
  {
    name: "Vikramjit Singh",
    location: "Amritsar",
    rating: 5,
    comment: "Superb budget luxury rooms! We booked the Triple Bed Room. Extremely spacious, clean beds, and excellent room service. Perfect for families doing the Vaishno Devi & Amarnath Yatra pilgrimage.",
    date: "April 2026",
  },
  {
    name: "Meera & Rajesh Patel",
    location: "Ahmedabad",
    rating: 5,
    comment: "Pure vegetarian food in the restaurant was delicious and hygienic. The hotel is walking distance to Ban Ganga. The direct travel guide saved us from a lot of agents. Genuine 5-star experience!",
    date: "March 2026",
  },
];

export default function Testimonials() {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % TESTIMONIALS_DATA.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + TESTIMONIALS_DATA.length) % TESTIMONIALS_DATA.length);
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % TESTIMONIALS_DATA.length);
  };

  return (
    <section id="testimonials" className="py-24 sm:py-32 bg-luxury-black text-white relative overflow-hidden">
      {/* Golden lighting accents */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gold/5 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
        
        {/* Section Heading */}
        <div className="space-y-3 mb-16">
          <span className="font-sans text-xs sm:text-sm font-bold text-gold uppercase tracking-[0.3em] block">
            Guest Experiences
          </span>
          <h2 className="font-display text-3xl sm:text-4xl font-bold tracking-wide text-white">
            Trusted by <span className="serif-italics font-serif text-gold font-normal">Pilgrims</span>
          </h2>
          <div className="w-16 h-[1px] bg-gold mx-auto mt-4"></div>
        </div>

        {/* Floating Quote Icon */}
        <div className="flex justify-center mb-6">
          <div className="p-4 bg-gold/10 text-gold border border-gold/25 rounded-none">
            <Quote className="w-8 h-8 rotate-180" />
          </div>
        </div>

        {/* Auto-sliding Glassmorphic Review card with AnimatePresence */}
        <div className="min-h-[250px] flex items-center justify-center relative">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentIndex}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.5, ease: "easeInOut" }}
              className="glass-card-dark p-8 sm:p-12 border border-gold/15 shadow-2xl max-w-2xl mx-auto flex flex-col justify-between"
            >
              <div className="space-y-6">
                {/* 5 Golden Stars */}
                <div className="flex justify-center space-x-1">
                  {[...Array(TESTIMONIALS_DATA[currentIndex].rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-gold text-gold" />
                  ))}
                </div>

                {/* Comment Text */}
                <p className="font-serif text-base sm:text-lg text-gray-200 leading-relaxed italic">
                  "{TESTIMONIALS_DATA[currentIndex].comment}"
                </p>

                {/* Divider Line */}
                <div className="w-12 h-[1px] bg-gold/20 mx-auto" />

                {/* User Info details */}
                <div>
                  <h4 className="font-display text-xs font-bold tracking-widest text-gold uppercase">
                    {TESTIMONIALS_DATA[currentIndex].name}
                  </h4>
                  <p className="font-sans text-[10px] text-gray-400 uppercase tracking-widest mt-1">
                    {TESTIMONIALS_DATA[currentIndex].location} &bull; {TESTIMONIALS_DATA[currentIndex].date}
                  </p>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>

          {/* Quick Left / Right Side Arrows */}
          <button
            onClick={handlePrev}
            className="absolute left-0 sm:-left-12 text-white hover:text-gold p-2 transition-colors"
            aria-label="Previous Review"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <button
            onClick={handleNext}
            className="absolute right-0 sm:-right-12 text-white hover:text-gold p-2 transition-colors"
            aria-label="Next Review"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        </div>

        {/* Carousel indicators/dot controls */}
        <div className="flex justify-center space-x-2 mt-8">
          {TESTIMONIALS_DATA.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentIndex(idx)}
              className={`h-1.5 transition-all duration-300 rounded-none ${
                idx === currentIndex ? "w-8 bg-gold" : "w-1.5 bg-white/20 hover:bg-white"
              }`}
              aria-label={`Go to slide ${idx + 1}`}
            />
          ))}
        </div>

        {/* Trusted Trust Badges */}
        <div className="mt-16 pt-10 border-t border-white/5 grid grid-cols-2 md:grid-cols-4 gap-6 items-center">
          <div className="flex flex-col items-center">
            <span className="font-display text-2xl font-bold text-gold">4.9/5</span>
            <span className="font-sans text-[8px] tracking-widest uppercase text-gray-400 mt-1">Google Reviews</span>
          </div>
          <div className="flex flex-col items-center">
            <span className="font-display text-2xl font-bold text-gold">100%</span>
            <span className="font-sans text-[8px] tracking-widest uppercase text-gray-400 mt-1">Pure Veg Hygienic</span>
          </div>
          <div className="flex flex-col items-center">
            <span className="font-display text-2xl font-bold text-gold">10k+</span>
            <span className="font-sans text-[8px] tracking-widest uppercase text-gray-400 mt-1">Pilgrims Hosted</span>
          </div>
          <div className="flex flex-col items-center">
            <span className="font-display text-2xl font-bold text-gold">24/7</span>
            <span className="font-sans text-[8px] tracking-widest uppercase text-gray-400 mt-1">Yatra Assistance</span>
          </div>
        </div>

      </div>
    </section>
  );
}
