import {
  MapPin,
  Bus,
  Users,
  Compass,
  Mountain,
  Map,
  Clock,
  Sparkles,
  Bed,
} from "lucide-react";

export default function WhyChooseUs() {
  const points = [
    {
      title: "Near Ban Ganga",
      desc: "Located on Ban Ganga Road, perfect starting point for your foot journey/trek to the Bhawan.",
      icon: MapPin,
    },
    {
      title: "Near Bus Stand",
      desc: "Superb transit accessibility, being within close walking distance from the main Katra Bus Stand.",
      icon: Bus,
    },
    {
      title: "Family Friendly",
      desc: "Warm and safe hospitality customized especially for pilgrims with children and senior citizens.",
      icon: Users,
    },
    {
      title: "Best for Vaishno Devi Yatra",
      desc: "Complete spiritual yatra support, including slip generation advice and luggage storage during your climb.",
      icon: Compass,
    },
    {
      title: "Best for Amarnath Yatra",
      desc: "The trusted transit lodge for pilgrims heading onwards to Srinagar, Baltal, or Pahalgam routing.",
      icon: Mountain,
    },
    {
      title: "Free Travel Guidance",
      desc: "Local destination expertise on horse bookings, battery cars, helicopter rides, and weather updates.",
      icon: Map,
    },
    {
      title: "24×7 Assistance",
      desc: "Our supportive reception desk operates around the clock to cater to late arrivals and early departures.",
      icon: Clock,
    },
    {
      title: "Clean & Hygienic Rooms",
      desc: "Strict professional sanitisation practices, fresh sanitised linens, and pristine attached washrooms.",
      icon: Sparkles,
    },
    {
      title: "Comfortable Beds",
      desc: "Ultra-comfy orthopaedic mattresses and premium pillows guaranteeing restful sleep after physical treks.",
      icon: Bed,
    },
  ];

  return (
    <section id="why-choose-us" className="py-24 sm:py-32 bg-luxury-black text-white relative overflow-hidden">
      {/* Absolute Decorative Golden Ambient Light */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-gold/5 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-gold/5 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Heading */}
        <div className="text-center space-y-3 mb-20">
          <span className="font-sans text-xs sm:text-sm font-bold text-gold uppercase tracking-[0.3em] block">
            The Maa Chaya Promise
          </span>
          <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold tracking-wide text-white">
            Why Pilgrims <span className="serif-italics font-serif text-gold font-normal">Choose Us</span>
          </h2>
          <div className="w-24 h-[1px] bg-gold mx-auto mt-4"></div>
          <p className="font-sans text-xs sm:text-sm text-gray-400 max-w-xl mx-auto font-light tracking-wide mt-3">
            Experience premium service designed specifically to assist you in your holy pilgrimage.
          </p>
        </div>

        {/* 3x3 Grid of Features */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {points.map((point, index) => {
            const Icon = point.icon;
            return (
              <div
                key={index}
                className="group relative p-8 glass hover:border-gold/35 transition-all duration-300 hover:translate-y-[-4px] flex flex-col justify-between"
              >
                {/* Background Accent Fade */}
                <div className="absolute inset-0 bg-gradient-to-tr from-gold/0 to-gold/0 group-hover:to-gold/5 transition-all duration-300 pointer-events-none" />

                <div className="space-y-4">
                  {/* Icon Block */}
                  <div className="p-3 bg-gold/10 text-gold border border-gold/20 inline-block">
                    <Icon className="w-6 h-6 group-hover:scale-110 transition-transform duration-300" />
                  </div>

                  {/* Title & Desc */}
                  <h3 className="font-display text-sm font-bold tracking-widest text-white uppercase group-hover:text-gold transition-colors duration-200">
                    {point.title}
                  </h3>
                  <p className="font-sans text-xs text-gray-400 leading-relaxed font-light">
                    {point.desc}
                  </p>
                </div>

                {/* Decorative border bottom */}
                <div className="w-0 h-[2px] bg-gold absolute bottom-0 left-0 transition-all duration-300 group-hover:w-full" />
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
