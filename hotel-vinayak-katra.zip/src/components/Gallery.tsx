import React, { useState } from "react";
import { X, ChevronLeft, ChevronRight, Maximize2, Sparkles } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface GalleryItem {
  id: string;
  image: string;
  caption: string;
  category: "rooms" | "exterior" | "spiritual" | "dining";
}

const GALLERY_ITEMS: GalleryItem[] = [
  {
    id: "gal-1",
    image: "https://images.unsplash.com/photo-1566073771259-6a8506099945?q=80&w=1000",
    caption: "Grand Entrance & Royal Facade",
    category: "exterior",
  },
  {
    id: "gal-2",
    image: "https://images.unsplash.com/photo-1582719508461-905c673771fd?q=80&w=1000",
    caption: "Premium Double Bed Suite",
    category: "rooms",
  },
  {
    id: "gal-3",
    image: "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?q=80&w=1000",
    caption: "Scenic Trikuta Mountains View",
    category: "spiritual",
  },
  {
    id: "gal-4",
    image: "https://images.unsplash.com/photo-1590490360182-c33d57733427?q=80&w=1000",
    caption: "Family Triple Bed Suite",
    category: "rooms",
  },
  {
    id: "gal-5",
    image: "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?q=80&w=1000",
    caption: "Exquisite Guest Lounge & Reception",
    category: "exterior",
  },
  {
    id: "gal-6",
    image: "https://images.unsplash.com/photo-1544644181-1484b3fdfc62?q=80&w=1000",
    caption: "Sacred Arti Ceremonies (Spiritual Vibe)",
    category: "spiritual",
  },
  {
    id: "gal-7",
    image: "https://images.unsplash.com/photo-1562680378-c30d8c279af5?q=80&w=1000",
    caption: "Hygienic Traditional Pure Vegetarian Meals",
    category: "dining",
  },
  {
    id: "gal-8",
    image: "https://images.unsplash.com/photo-1517840901100-8179e982acb7?q=80&w=1000",
    caption: "Premium Lobby Desk Support",
    category: "exterior",
  },
];

export default function Gallery() {
  const [activeCategory, setActiveCategory] = useState<string>("all");
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  const categories = [
    { key: "all", label: "All Photos" },
    { key: "rooms", label: "Rooms & Suites" },
    { key: "exterior", label: "Exterior & Lobby" },
    { key: "spiritual", label: "Spiritual Vibe" },
    { key: "dining", label: "Hygienic Dining" },
  ];

  const filteredItems = GALLERY_ITEMS.filter((item) =>
    activeCategory === "all" ? true : item.category === activeCategory
  );

  const handlePrev = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (lightboxIndex !== null) {
      setLightboxIndex((prev) =>
        prev !== null ? (prev - 1 + filteredItems.length) % filteredItems.length : null
      );
    }
  };

  const handleNext = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (lightboxIndex !== null) {
      setLightboxIndex((prev) =>
        prev !== null ? (prev + 1) % filteredItems.length : null
      );
    }
  };

  return (
    <section id="gallery" className="py-24 sm:py-32 bg-luxury-black relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="text-center space-y-3 mb-16">
          <span className="font-sans text-xs sm:text-sm font-bold text-gold uppercase tracking-[0.3em] block">
            Visual Experience
          </span>
          <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold tracking-wide text-white">
            The Luxury <span className="serif-italics font-serif text-gold font-normal">Gallery</span>
          </h2>
          <div className="w-24 h-[1px] bg-gold mx-auto mt-4"></div>
          <p className="font-sans text-xs sm:text-sm text-gray-300 max-w-xl mx-auto font-light tracking-wide mt-3">
            Glimpse our pristine rooms, welcoming spaces, delicious meals, and spiritual surroundings in Katra.
          </p>
        </div>

        {/* Filter Category Tabs */}
        <div className="flex flex-wrap justify-center gap-3 sm:gap-6 mb-12">
          {categories.map((cat) => (
            <button
              key={cat.key}
              onClick={() => setActiveCategory(cat.key)}
              className={`font-sans text-[10px] sm:text-xs font-bold uppercase tracking-widest px-5 py-2.5 transition-all duration-300 rounded-none border cursor-pointer ${
                activeCategory === cat.key
                  ? "bg-gold border-gold text-luxury-black font-bold shadow-md shadow-gold/25"
                  : "bg-white/5 border-gold/20 text-gray-300 hover:text-gold hover:border-gold backdrop-blur-md"
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Masonry / Grid Layout with scale zoom animations */}
        <div className="columns-1 sm:columns-2 md:columns-3 lg:columns-4 gap-6 space-y-6">
          <AnimatePresence mode="popLayout">
            {filteredItems.map((item, index) => (
              <motion.div
                layout
                key={item.id}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.4 }}
                onClick={() => setLightboxIndex(index)}
                className="break-inside-avoid relative overflow-hidden group shadow-md hover:shadow-2xl border border-gold/10 cursor-zoom-in"
              >
                {/* Image */}
                <img
                  src={item.image}
                  alt={item.caption}
                  loading="lazy"
                  className="w-full object-cover transition-transform duration-700 group-hover:scale-110 filter brightness-[0.95]"
                  referrerPolicy="no-referrer"
                />

                {/* Golden Overlay Hover Mask */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6">
                  <div className="translate-y-4 group-hover:translate-y-0 transition-transform duration-500 space-y-2">
                    <div className="flex items-center space-x-1">
                      <Sparkles className="w-3.5 h-3.5 text-gold" />
                      <span className="font-sans text-[9px] font-bold text-gold tracking-widest uppercase">
                        {item.category}
                      </span>
                    </div>
                    <h3 className="font-display text-xs font-bold text-white tracking-wider uppercase">
                      {item.caption}
                    </h3>
                    <span className="inline-flex items-center space-x-1.5 text-gold text-[10px] font-semibold uppercase tracking-widest pt-1">
                      <Maximize2 className="w-3 h-3" />
                      <span>Zoom View</span>
                    </span>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* Custom Lightbox Portal Overlay */}
        <AnimatePresence>
          {lightboxIndex !== null && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setLightboxIndex(null)}
              className="fixed inset-0 z-50 bg-black/95 backdrop-blur-md flex flex-col justify-between p-4 sm:p-8"
            >
              {/* Top Control Bar */}
              <div className="flex justify-between items-center w-full max-w-7xl mx-auto z-10">
                <span className="font-sans text-[10px] text-gray-400 font-bold uppercase tracking-widest">
                  Photo {lightboxIndex + 1} of {filteredItems.length} &bull; {filteredItems[lightboxIndex].category}
                </span>
                <button
                  onClick={() => setLightboxIndex(null)}
                  className="text-white hover:text-gold p-2 transition-colors duration-200"
                  title="Close Lightbox"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              {/* Central Carousel */}
              <div className="flex-grow flex items-center justify-between max-w-7xl mx-auto w-full relative">
                {/* Previous Button */}
                <button
                  onClick={handlePrev}
                  className="absolute left-0 sm:left-4 z-10 bg-black/40 hover:bg-gold hover:text-luxury-black text-white p-2.5 sm:p-4 rounded-none border border-white/10 transition-all duration-200"
                  title="Previous Image"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>

                {/* Main Image View */}
                <div className="mx-auto max-w-4xl max-h-[70vh] flex flex-col items-center justify-center p-4">
                  <motion.img
                    key={lightboxIndex}
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    transition={{ duration: 0.3 }}
                    src={filteredItems[lightboxIndex].image}
                    alt={filteredItems[lightboxIndex].caption}
                    className="max-w-full max-h-[60vh] object-contain border border-gold/20 shadow-2xl"
                    referrerPolicy="no-referrer"
                    onClick={(e) => e.stopPropagation()}
                  />
                  <motion.p
                    key={`caption-${lightboxIndex}`}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 }}
                    className="font-display text-xs sm:text-sm font-semibold tracking-wider text-white uppercase text-center mt-6 border-b border-gold/20 pb-2"
                  >
                    {filteredItems[lightboxIndex].caption}
                  </motion.p>
                </div>

                {/* Next Button */}
                <button
                  onClick={handleNext}
                  className="absolute right-0 sm:right-4 z-10 bg-black/40 hover:bg-gold hover:text-luxury-black text-white p-2.5 sm:p-4 rounded-none border border-white/10 transition-all duration-200"
                  title="Next Image"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>

              {/* Bottom Info bar */}
              <div className="text-center pb-2 z-10">
                <span className="font-serif italic text-gold text-xs">
                  "Excellence in Pilgrimage Hospitality"
                </span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

      </div>
    </section>
  );
}
