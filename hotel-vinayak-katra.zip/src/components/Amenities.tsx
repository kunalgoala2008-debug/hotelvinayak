import {
  Wifi,
  Utensils,
  BellRing,
  Car,
  HeartHandshake,
  Compass,
  ArrowUp,
  Zap,
  Flame,
  Home,
  Sparkles,
} from "lucide-react";

export default function Amenities() {
  const amenitiesList = [
    {
      name: "Free WiFi",
      desc: "High-speed internet throughout the hotel premises, keeping you connected.",
      icon: Wifi,
    },
    {
      name: "In-House Restaurant",
      desc: "Serving hygienic, delicious vegetarian meals prepared fresh for pilgrims.",
      icon: Utensils,
    },
    {
      name: "Room Service",
      desc: "Enjoy hot tea, delicious meals, and help delivered right to your door.",
      icon: BellRing,
    },
    {
      name: "Complimentary Parking",
      desc: "Safe and spacious parking area on-site for your personal cars and tourist buses.",
      icon: Car,
    },
    {
      name: "24x7 Reception",
      desc: "Round-the-clock warm welcome, checking, security support, and assistance.",
      icon: HeartHandshake,
    },
    {
      name: "Travel Assistance",
      desc: "Expert guidelines, helicopter booking advice, and pony/palki coordination.",
      icon: Compass,
    },
    {
      name: "Modern Lift/Elevator",
      desc: "Full floor accessibility with an automated elevator for elderly family members.",
      icon: ArrowUp,
    },
    {
      name: "100% Power Backup",
      desc: "Automated high-capacity generators ensuring power round the clock.",
      icon: Zap,
    },
    {
      name: "24 Hours Hot Water",
      desc: "Reliable hot water supply in all bathrooms for soothing baths after mountain treks.",
      icon: Flame,
    },
    {
      name: "Family Rooms",
      desc: "Spacious multi-bed floor layouts custom configured for families and groups.",
      icon: Home,
    },
    {
      name: "Daily Housekeeping",
      desc: "Rigorous room sanitisation, cleaning, and replacement of towels and linens.",
      icon: Sparkles,
    },
  ];

  return (
    <section id="facilities" className="py-24 sm:py-32 bg-luxury-black relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="text-center space-y-3 mb-20">
          <span className="font-sans text-xs sm:text-sm font-bold text-gold uppercase tracking-[0.3em] block">
            State-of-the-Art
          </span>
          <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold tracking-wide text-white">
            Hotel <span className="serif-italics font-serif text-gold font-normal">Facilities & Amenities</span>
          </h2>
          <div className="w-24 h-[1px] bg-gold mx-auto mt-4"></div>
          <p className="font-sans text-xs sm:text-sm text-gray-300 max-w-xl mx-auto font-light tracking-wide mt-3">
            Every feature carefully crafted to support your spiritual stay with maximum peace of mind.
          </p>
        </div>

        {/* Bento Grid / Modular Cards Layout */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {amenitiesList.map((amenity, index) => {
            const Icon = amenity.icon;
            return (
              <div
                key={index}
                className="group glass p-6 hover:border-gold hover:bg-white/10 shadow-lg hover:translate-y-[-2px] transition-all duration-300 flex flex-col justify-between"
              >
                <div className="space-y-4">
                  {/* Icon Block */}
                  <div className="p-3 bg-white/5 text-gold border border-gold/10 inline-block group-hover:bg-gold group-hover:text-luxury-black transition-colors duration-300">
                    <Icon className="w-5 h-5" />
                  </div>

                  {/* Text Details */}
                  <h3 className="font-display text-xs font-bold tracking-widest text-white uppercase">
                    {amenity.name}
                  </h3>
                  <p className="font-sans text-xs text-gray-400 leading-relaxed font-light">
                    {amenity.desc}
                  </p>
                </div>

                {/* Micro visual bar indicator */}
                <div className="w-6 h-[1.5px] bg-gold/30 group-hover:w-full transition-all duration-300 mt-6" />
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
