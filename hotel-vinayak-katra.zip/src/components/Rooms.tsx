import { Wifi, Tv, Flame, Wind, CheckCircle2, Shield, Sparkles } from "lucide-react";

interface RoomsProps {
  onBookRoom: (roomName: string, planName: string) => void;
}

export default function Rooms({ onBookRoom }: RoomsProps) {
  const roomsData = [
    {
      id: "double",
      name: "DOUBLE BED ROOM",
      tagline: "Elegant Sanctuary for Couples & Small Families",
      image: "https://images.unsplash.com/photo-1618773928121-c32242e63f39?q=80&w=1200",
      occupancy: "Perfect for 2 Guests",
      plans: [
        { name: "EP Plan", price: 1500, label: "Room Only" },
        { name: "AP Plan", price: 1800, label: "All Meals Included" },
        { name: "MAP Plan", price: 2400, label: "Breakfast & Dinner" },
      ],
      amenities: [
        { name: "Free WiFi", icon: Wifi },
        { name: "Air Conditioning", icon: Wind },
        { name: "LED TV", icon: Tv },
        { name: "24h Hot Water", icon: Flame },
        { name: "Attached Bathroom", icon: Shield },
        { name: "Room Service", icon: CheckCircle2 },
      ],
    },
    {
      id: "triple",
      name: "TRIPLE BED ROOM",
      tagline: "Spacious Comfort Tailored for Pilgrimage Families",
      image: "https://images.unsplash.com/photo-1590490360182-c33d57733427?q=80&w=1200",
      occupancy: "Perfect for 3-4 Guests",
      plans: [
        { name: "EP Plan", price: 1800, label: "Room Only" },
        { name: "AP Plan", price: 2400, label: "All Meals Included" },
        { name: "MAP Plan", price: 3300, label: "Breakfast & Dinner" },
      ],
      amenities: [
        { name: "Free WiFi", icon: Wifi },
        { name: "Air Conditioning", icon: Wind },
        { name: "LED TV", icon: Tv },
        { name: "24h Hot Water", icon: Flame },
        { name: "Attached Bathroom", icon: Shield },
        { name: "Room Service", icon: CheckCircle2 },
      ],
    },
  ];

  return (
    <section id="rooms" className="py-24 sm:py-32 bg-luxury-black relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="text-center space-y-3 mb-20">
          <span className="font-sans text-xs sm:text-sm font-bold text-gold uppercase tracking-[0.3em] block">
            Accommodations
          </span>
          <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold tracking-wide text-white">
            Our Luxury <span className="serif-italics font-serif text-gold font-normal">Suites & Rooms</span>
          </h2>
          <div className="w-24 h-[1px] bg-gold mx-auto mt-4"></div>
          <p className="font-sans text-xs sm:text-sm text-gray-300 max-w-xl mx-auto font-light tracking-wide mt-3">
            Elegantly appointed rooms providing calm, hygienic rest after your spiritual journey to Mata Vaishno Devi.
          </p>
        </div>

        {/* Room Cards Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 sm:gap-16">
          {roomsData.map((room) => (
            <div
              key={room.id}
              className="group glass border border-gold/25 flex flex-col justify-between overflow-hidden shadow-2xl hover:shadow-[0_20px_50px_rgba(212,175,55,0.08)] transition-all duration-500"
            >
              {/* Room Image Container */}
              <div className="relative aspect-[16/10] w-full overflow-hidden border-b border-gold/15">
                <img
                  src={room.image}
                  alt={room.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 filter brightness-[0.85]"
                  referrerPolicy="no-referrer"
                />
                
                {/* Visual Occupancy Badge */}
                <div className="absolute top-4 left-4 bg-luxury-black/95 backdrop-blur-md px-4 py-1.5 border border-gold/25 flex items-center space-x-1.5">
                  <Sparkles className="w-3 h-3 text-gold" />
                  <span className="font-sans text-[10px] font-bold text-gold tracking-widest uppercase">
                    {room.occupancy}
                  </span>
                </div>
              </div>

              {/* Room Body Details */}
              <div className="p-6 sm:p-8 space-y-6 flex-grow flex flex-col justify-between">
                <div>
                  <h3 className="font-display text-lg sm:text-xl font-bold text-white tracking-widest uppercase mb-1">
                    {room.name}
                  </h3>
                  <p className="font-serif text-xs text-gold italic mb-4">
                    {room.tagline}
                  </p>
                  
                  {/* Divider */}
                  <div className="h-[1px] bg-gold/15 my-4" />

                  {/* Room Amenities list with custom labels */}
                  <div className="grid grid-cols-3 gap-y-4 gap-x-2 py-2">
                    {room.amenities.map((item, idx) => {
                      const Icon = item.icon;
                      return (
                        <div key={idx} className="flex items-center space-x-2">
                          <div className="p-1.5 bg-white/5 text-gold border border-gold/15">
                            <Icon className="w-3.5 h-3.5" />
                          </div>
                          <span className="font-sans text-[10px] text-gray-300 font-medium tracking-wide">
                            {item.name}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Pricing Blocks Section */}
                <div className="mt-6 pt-6 border-t border-gold/15">
                  <h4 className="font-display text-[10px] font-bold text-white tracking-widest uppercase mb-4">
                    Pricing Plans & Tariffs
                  </h4>
                  
                  <div className="grid grid-cols-3 gap-3">
                    {room.plans.map((plan) => (
                      <button
                        key={plan.name}
                        onClick={() => onBookRoom(room.name, plan.name)}
                        className="bg-white/5 border border-gold/15 hover:border-gold hover:bg-white/10 p-3 text-center flex flex-col justify-between hover:translate-y-[-2px] transition-all duration-300 group/plan"
                      >
                        <span className="font-sans text-[10px] font-bold text-white tracking-wider uppercase">
                          {plan.name}
                        </span>
                        <span className="font-display text-sm sm:text-base font-extrabold text-gold py-1 group-hover/plan:text-gold-light">
                          ₹{plan.price}
                        </span>
                        <span className="font-sans text-[8px] text-gray-400 uppercase font-semibold">
                          {plan.label}
                        </span>
                      </button>
                    ))}
                  </div>

                  <p className="font-sans text-[9px] text-gray-400 mt-3 text-right">
                    *Taxes extra as applicable. Meal plans are customisable.
                  </p>
                </div>
              </div>

              {/* Bottom Book CTA block */}
              <div className="px-6 pb-6 sm:px-8 sm:pb-8">
                <button
                  id={`book-btn-${room.id}`}
                  onClick={() => onBookRoom(room.name, "EP Plan")}
                  className="w-full bg-gold hover:bg-white text-luxury-black font-sans text-xs font-bold uppercase tracking-widest py-3.5 transition-all duration-300 border border-gold/20 hover:border-gold hover:shadow-[0_0_15px_rgba(212,175,55,0.25)] cursor-pointer"
                >
                  Book {room.name} Now
                </button>
              </div>

            </div>
          ))}
        </div>

        {/* Dynamic description info */}
        <div className="mt-16 p-6 glass border border-gold/20 flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center space-x-3">
            <span className="p-2.5 bg-white/5 text-gold rounded-none border border-gold/20 font-bold font-sans text-sm">
              ℹ
            </span>
            <div>
              <h4 className="font-display text-xs font-bold tracking-wider text-white uppercase">
                Yatra Meal Plan Explainer
              </h4>
              <p className="font-sans text-xs text-gray-300 font-light mt-0.5">
                <strong>EP:</strong> European Plan (Room Only). <strong>AP:</strong> American Plan (All Meals). <strong>MAP:</strong> Modified American Plan (Breakfast + Dinner).
              </p>
            </div>
          </div>
          <div className="text-center md:text-right">
            <span className="font-sans text-[10px] font-bold text-gray-400 uppercase block">
              Direct Helpline 24x7
            </span>
            <a href="tel:+919650625613" className="font-sans text-sm font-extrabold text-gold hover:text-gold-dark transition-colors duration-200">
              +91 9650625613
            </a>
          </div>
        </div>

      </div>
    </section>
  );
}
